(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gwendall:body-events'] = {};

})();

//# sourceMappingURL=gwendall_body-events.js.map
