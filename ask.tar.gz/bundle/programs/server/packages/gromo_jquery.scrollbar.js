(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gromo:jquery.scrollbar'] = {};

})();

//# sourceMappingURL=gromo_jquery.scrollbar.js.map
