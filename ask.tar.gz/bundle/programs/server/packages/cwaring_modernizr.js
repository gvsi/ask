(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['cwaring:modernizr'] = {};

})();

//# sourceMappingURL=cwaring_modernizr.js.map
