(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:mathjax'] = {};

})();

//# sourceMappingURL=mrt_mathjax.js.map
