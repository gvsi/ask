(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Counts, publishCount;

(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/tmeasday:publish-counts/publish-counts.js                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
var noWarnings = false;                                                                                             // 1
                                                                                                                    // 2
if (Meteor.isServer) {                                                                                              // 3
  Counts = {};                                                                                                      // 4
  Counts.publish = function(self, name, cursor, options) {                                                          // 5
    var initializing = true;                                                                                        // 6
    var handle;                                                                                                     // 7
    options = options || {};                                                                                        // 8
                                                                                                                    // 9
    var extraField, countFn;                                                                                        // 10
                                                                                                                    // 11
    if (options.countFromField) {                                                                                   // 12
      extraField = options.countFromField;                                                                          // 13
      if ('function' === typeof extraField) {                                                                       // 14
        countFn = Counts._safeAccessorFunction(extraField);                                                         // 15
      } else {                                                                                                      // 16
        countFn = function(doc) {                                                                                   // 17
          return doc[extraField] || 0;    // return 0 instead of undefined.                                         // 18
        }                                                                                                           // 19
      }                                                                                                             // 20
    } else if (options.countFromFieldLength) {                                                                      // 21
      extraField = options.countFromFieldLength;                                                                    // 22
      if ('function' === typeof extraField) {                                                                       // 23
        countFn = Counts._safeAccessorFunction(function (doc) {                                                     // 24
          return extraField(doc).length;                                                                            // 25
        });                                                                                                         // 26
      } else {                                                                                                      // 27
        countFn = function(doc) {                                                                                   // 28
          if (doc[extraField]) {                                                                                    // 29
            return doc[extraField].length;                                                                          // 30
          } else {                                                                                                  // 31
            return 0;                                                                                               // 32
          }                                                                                                         // 33
        }                                                                                                           // 34
      }                                                                                                             // 35
    }                                                                                                               // 36
                                                                                                                    // 37
                                                                                                                    // 38
    if (countFn && options.nonReactive)                                                                             // 39
      throw new Error("options.nonReactive is not yet supported with options.countFromFieldLength or options.countFromFieldSum");
                                                                                                                    // 41
    cursor._cursorDescription.options.fields =                                                                      // 42
      Counts._optimizeQueryFields(cursor._cursorDescription.options.fields, extraField, options.noWarnings);        // 43
                                                                                                                    // 44
    var count = 0;                                                                                                  // 45
    var observers = {                                                                                               // 46
      added: function(doc) {                                                                                        // 47
        if (countFn) {                                                                                              // 48
          count += countFn(doc);                                                                                    // 49
        } else {                                                                                                    // 50
          count += 1;                                                                                               // 51
        }                                                                                                           // 52
                                                                                                                    // 53
        if (!initializing)                                                                                          // 54
          self.changed('counts', name, {count: count});                                                             // 55
      },                                                                                                            // 56
      removed: function(doc) {                                                                                      // 57
        if (countFn) {                                                                                              // 58
          count -= countFn(doc);                                                                                    // 59
        } else {                                                                                                    // 60
          count -= 1;                                                                                               // 61
        }                                                                                                           // 62
        self.changed('counts', name, {count: count});                                                               // 63
      }                                                                                                             // 64
    };                                                                                                              // 65
                                                                                                                    // 66
    if (countFn) {                                                                                                  // 67
      observers.changed = function(newDoc, oldDoc) {                                                                // 68
        if (countFn) {                                                                                              // 69
          count += countFn(newDoc) - countFn(oldDoc);                                                               // 70
        }                                                                                                           // 71
                                                                                                                    // 72
        self.changed('counts', name, {count: count});                                                               // 73
      };                                                                                                            // 74
    }                                                                                                               // 75
                                                                                                                    // 76
    if (!countFn) {                                                                                                 // 77
      self.added('counts', name, {count: cursor.count()});                                                          // 78
      if (!options.noReady)                                                                                         // 79
        self.ready();                                                                                               // 80
    }                                                                                                               // 81
                                                                                                                    // 82
    if (!options.nonReactive)                                                                                       // 83
      handle = cursor.observe(observers);                                                                           // 84
                                                                                                                    // 85
    if (countFn)                                                                                                    // 86
      self.added('counts', name, {count: count});                                                                   // 87
                                                                                                                    // 88
    if (!options.noReady)                                                                                           // 89
      self.ready();                                                                                                 // 90
                                                                                                                    // 91
    initializing = false;                                                                                           // 92
                                                                                                                    // 93
    self.onStop(function() {                                                                                        // 94
      if (handle)                                                                                                   // 95
        handle.stop();                                                                                              // 96
    });                                                                                                             // 97
                                                                                                                    // 98
    return {                                                                                                        // 99
      stop: function() {                                                                                            // 100
        if (handle) {                                                                                               // 101
          handle.stop();                                                                                            // 102
          handle = undefined;                                                                                       // 103
        }                                                                                                           // 104
      }                                                                                                             // 105
    };                                                                                                              // 106
  };                                                                                                                // 107
  // back compatibility                                                                                             // 108
  publishCount = Counts.publish;                                                                                    // 109
                                                                                                                    // 110
  Counts.noWarnings = function (noWarn) {                                                                           // 111
    // suppress warnings if no arguments, or first argument is truthy                                               // 112
    noWarnings = (0 == arguments.length || !!noWarn);                                                               // 113
  }                                                                                                                 // 114
                                                                                                                    // 115
  Counts._safeAccessorFunction = function safeAccessorFunction (fn) {                                               // 116
    // ensure that missing fields don't corrupt the count.  If the count field                                      // 117
    // doesn't exist, then it has a zero count.                                                                     // 118
    return function (doc) {                                                                                         // 119
      try {                                                                                                         // 120
        return fn(doc) || 0;    // return 0 instead of undefined                                                    // 121
      }                                                                                                             // 122
      catch (err) {                                                                                                 // 123
        if (err instanceof TypeError) {   // attempted to access property of undefined (i.e. deep access).          // 124
          return 0;                                                                                                 // 125
        } else {                                                                                                    // 126
          throw err;                                                                                                // 127
        }                                                                                                           // 128
      }                                                                                                             // 129
    };                                                                                                              // 130
  }                                                                                                                 // 131
                                                                                                                    // 132
  Counts._optimizeQueryFields = function optimizeQueryFields (fields, extraField, noWarn) {                         // 133
    switch (typeof extraField) {                                                                                    // 134
      case 'function':      // accessor function used.                                                              // 135
        if (undefined === fields) {                                                                                 // 136
          // user did not place restrictions on cursor fields.                                                      // 137
          Counts._warn(noWarn,                                                                                      // 138
                       'publish-counts: Collection cursor has no field limits and will fetch entire documents.  ' + // 139
                       'consider specifying only required fields.');                                                // 140
          // if cursor field limits are empty to begin with, leave them empty.  it is the                           // 141
          // user's responsibility to specify field limits when using accessor functions.                           // 142
        }                                                                                                           // 143
        // else user specified restrictions on cursor fields.  Meteor will ensure _id is one of them.               // 144
        // WARNING: unable to verify user included appropriate field for accessor function to work.  we can't hold their hand ;_;
                                                                                                                    // 146
        return fields;                                                                                              // 147
                                                                                                                    // 148
      case 'string':        // countFromField or countFromFieldLength has property name.                            // 149
        // extra field is a property                                                                                // 150
                                                                                                                    // 151
        // automatically set limits if none specified.  keep existing limits since user                             // 152
        // may use a cursor transform and specify a dynamic field to count, but require other                       // 153
        // fields in the transform process  (e.g. https://github.com/percolatestudio/publish-counts/issues/47).     // 154
        fields = fields || {};                                                                                      // 155
        // _id and extraField are required                                                                          // 156
        fields._id = true;                                                                                          // 157
        fields[extraField] = true;                                                                                  // 158
                                                                                                                    // 159
        if (2 < _.keys(fields).length)                                                                              // 160
          Counts._warn(noWarn,                                                                                      // 161
                       'publish-counts: unused fields detected in cursor fields option',                            // 162
                       _.omit(fields, ['_id', extraField]));                                                        // 163
                                                                                                                    // 164
        // use modified field limits.  automatically defaults to _id and extraField if none specified by user.      // 165
        return fields;                                                                                              // 166
                                                                                                                    // 167
      case 'undefined':     // basic count                                                                          // 168
        if (fields && 0 < _.keys(_.omit(fields, ['_id'])).length)                                                   // 169
          Counts._warn(noWarn,                                                                                      // 170
                       'publish-counts: unused fields removed from cursor fields option.',                          // 171
                       _.omit(fields, ['_id']));                                                                    // 172
                                                                                                                    // 173
        // dispose of user field limits, only _id is required                                                       // 174
        fields = { _id:  true };                                                                                    // 175
                                                                                                                    // 176
        // use modified field limits.  automatically defaults to _id if none specified by user.                     // 177
        return fields;                                                                                              // 178
                                                                                                                    // 179
      default:                                                                                                      // 180
        throw new Error("unknown invocation of Count.publish() detected.");                                         // 181
    }                                                                                                               // 182
  }                                                                                                                 // 183
                                                                                                                    // 184
  Counts._warn = function warn (noWarn) {                                                                           // 185
    if (noWarnings || noWarn || 'production' == process.env.NODE_ENV)                                               // 186
      return;                                                                                                       // 187
                                                                                                                    // 188
    var args = Array.prototype.slice.call(arguments, 1);                                                            // 189
    console.warn.apply(console, args);                                                                              // 190
  }                                                                                                                 // 191
}                                                                                                                   // 192
                                                                                                                    // 193
if (Meteor.isClient) {                                                                                              // 194
  Counts = new Mongo.Collection('counts');                                                                          // 195
                                                                                                                    // 196
  Counts.get = function countsGet (name) {                                                                          // 197
    var count = this.findOne(name);                                                                                 // 198
    return count && count.count || 0;                                                                               // 199
  };                                                                                                                // 200
                                                                                                                    // 201
  Counts.has = function countsHas (name) {                                                                          // 202
    return !!this.findOne(name);                                                                                    // 203
  }                                                                                                                 // 204
                                                                                                                    // 205
  if (Package.templating) {                                                                                         // 206
    Package.templating.Template.registerHelper('getPublishedCount', function(name) {                                // 207
      return Counts.get(name);                                                                                      // 208
    });                                                                                                             // 209
  }                                                                                                                 // 210
}                                                                                                                   // 211
                                                                                                                    // 212
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['tmeasday:publish-counts'] = {
  Counts: Counts,
  publishCount: publishCount
};

})();

//# sourceMappingURL=tmeasday_publish-counts.js.map
