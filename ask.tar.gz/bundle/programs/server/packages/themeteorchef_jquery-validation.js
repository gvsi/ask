(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['themeteorchef:jquery-validation'] = {};

})();

//# sourceMappingURL=themeteorchef_jquery-validation.js.map
