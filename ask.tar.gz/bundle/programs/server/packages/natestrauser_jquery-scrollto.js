(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['natestrauser:jquery-scrollto'] = {};

})();

//# sourceMappingURL=natestrauser_jquery-scrollto.js.map
