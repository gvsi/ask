(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['revox:pages-core'] = {};

})();

//# sourceMappingURL=revox_pages-core.js.map
