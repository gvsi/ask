(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['agnito:simptip'] = {};

})();

//# sourceMappingURL=agnito_simptip.js.map
