(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function () {

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/hillmark:meteor-identicon/hillmark:meteor-identicon.js        //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
// Write your package code here!                                          // 1
Package.blaze.UI.registerHelper('identicon', function(context, options) { // 2
  if(context) {                                                           // 3
  	var identicon = new Identicon(context, 256).toString();                // 4
  	return "data:image/png;base64," + identicon.toString();                // 5
  }	                                                                      // 6
});                                                                       // 7
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['hillmark:meteor-identicon'] = {};

})();

//# sourceMappingURL=hillmark_meteor-identicon.js.map
