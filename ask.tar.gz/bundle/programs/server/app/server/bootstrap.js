(function(){Meteor.startup(function() {
  Houston.add_collection(Meteor.users);
  Houston.add_collection(Houston._admins);
});

})();
