(function(){Students = new Mongo.Collection('students');

})();
